# This files downloads snort rules auto-update scripts

#!/bin/sh

DATE1=`date +%g%m%d`

F_LOC="/root/scripts/""$DATE1""_update.sh"

if [ -e "$F_LOC" ]
then
	echo "Update script already exist!"
	/root/scripts/"$DATE1"_update.sh
else
	wget http://www.fossa.kr/~bear/conf_files/"$DATE1"_update.sh -P /root/scripts/
	chmod +x /root/scripts/"$DATE1"_update.sh
	/root/scripts/"$DATE1"_update.sh
fi
